import React from 'react'

const FooterComponent = () => {
  return (
    <div className='Footer'>
    <p className='text-center'>Copyright Reserved</p>
    </div>
  )
}

export default FooterComponent
